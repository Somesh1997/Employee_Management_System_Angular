export class Employees {
  id: number;
  name: string;
  location: string;
  email: string;
  mobile:number;
  
}